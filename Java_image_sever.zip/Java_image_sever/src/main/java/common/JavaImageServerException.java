package common;

public class JavaImageServerException extends Exception {
    public JavaImageServerException(String message) {
        super(message);
    }
}
