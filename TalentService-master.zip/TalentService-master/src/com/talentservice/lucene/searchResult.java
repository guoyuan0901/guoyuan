package com.talentservice.lucene;

public class searchResult {
	private int house_id;
	private String house_name;
	private String house_rent_name;
	private String house_type_name;
	private int single_day_price;
	public int getHouse_id() {
		return house_id;
	}
	public void setHouse_id(int house_id) {
		this.house_id = house_id;
	}
	public String getHouse_name() {
		return house_name;
	}
	public void setHouse_name(String house_name) {
		this.house_name = house_name;
	}
	public String getHouse_rent_name() {
		return house_rent_name;
	}
	public void setHouse_rent_name(String house_rent_name) {
		this.house_rent_name = house_rent_name;
	}
	public String getHouse_type_name() {
		return house_type_name;
	}
	public void setHouse_type_name(String house_type_name) {
		this.house_type_name = house_type_name;
	}
	public int getSingle_day_price() {
		return single_day_price;
	}
	public void setSingle_day_price(int single_day_price) {
		this.single_day_price = single_day_price;
	}
}
