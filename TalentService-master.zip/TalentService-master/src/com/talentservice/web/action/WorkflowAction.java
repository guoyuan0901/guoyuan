package com.talentservice.web.action;

import com.talentservice.action.base.BaseAction;

public class WorkflowAction extends BaseAction {
	
	private static final long serialVersionUID = -7279809790270047798L;

	public Object getModel() {
		return null;
	}

}
