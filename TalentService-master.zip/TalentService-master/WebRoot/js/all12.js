// JavaScript Document

var w,k;
window.onload=function()
{
	w();
	k();
	
}