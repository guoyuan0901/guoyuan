// JavaScript Document
var k,zy,tj;
window.onload=function()
{
	
	zy("hehe","rtrtrtrt");
	tj();
	k();
}