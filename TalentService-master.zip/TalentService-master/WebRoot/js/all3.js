// JavaScript Document

var j,k,d,s;
window.onload=function()
{
	j();
	d();
	s();
	k();
	var um = UM.getEditor('myEditor');
}