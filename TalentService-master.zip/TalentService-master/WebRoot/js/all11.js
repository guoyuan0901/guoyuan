// JavaScript Document
var q,k;
window.onload=function()
{
	q();
	k();
}
