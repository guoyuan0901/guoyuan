// JavaScript Document
var k,e;
window.onload=function()
{
	e();
	k();
}