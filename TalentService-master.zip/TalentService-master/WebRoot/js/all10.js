// JavaScript Document
var k,p;
window.onload=function()
{
	p();
	k();
}