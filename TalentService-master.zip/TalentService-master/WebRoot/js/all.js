// JavaScript Document


var a,b,k,j;
window.onload=function()
{
	var timestamp = document.getElementById('timestamp') ;
	a(timestamp.innerHTML);
	b();
	j();
	k();
}