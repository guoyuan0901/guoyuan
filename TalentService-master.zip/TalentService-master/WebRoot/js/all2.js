// JavaScript Document
var k;
window.onload=function()
{
	k();
}