// JavaScript Document

var g,k;

window.onload=function()
{
	g();
	k();
}