// JavaScript Document
var k,t;
window.onload=function()
{
	
	new PCAS("deliverprovince","delivercity","deliverarea");
	t();
	k();	
}