// JavaScript Document
var h,k;
window.onload=function()
{
	h();
	k();
}
