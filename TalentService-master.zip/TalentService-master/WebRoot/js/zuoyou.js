// JavaScript Document

function zy(name,name2)
{
	var dibu=document.getElementById("dibu");
	var zuobian=document.getElementById("zuobian");
	var sige=dibu.getElementsByTagName("div");
	var limian='<div style="height:50px; font-size:26px; text-align:center; margin-top:70px; line-height:2em;">话题名称第三方斯蒂芬是身份</div><div style="height:30px; margin-top:20px; color:#909090; font-size:20px; text-align:center;">作者：'+name+'&nbsp;|&nbsp;2015-5-1&nbsp;|&nbsp;评论(3)&nbsp;|&nbsp;赞(5)&nbsp;|&nbsp;收藏(0)&nbsp;|&nbsp;浏览(123)</div><div style="margin-top:50px; height:1300px; width:750px; word-break:break-all; line-height:2em; letter-spacing:0.1em; text-indent:2em;">速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东方就<div style=" width:733px; height:488px; background:url(../images/yanshi.gif); margin:0 auto;"></div>速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东</div>';
	var limiann='<div style="height:50px; font-size:26px; text-align:center; margin-top:70px; line-height:2em;">话题名称第三方斯蒂芬是身份</div><div style="height:30px; margin-top:20px; color:#909090; font-size:20px; text-align:center;">作者：'+name2+'&nbsp;|&nbsp;2015-5-1&nbsp;|&nbsp;评论(3)&nbsp;|&nbsp;赞(5)&nbsp;|&nbsp;收藏(0)&nbsp;|&nbsp;浏览(123)</div><div style="margin-top:50px; height:1300px; width:750px; word-break:break-all; line-height:2em; letter-spacing:0.1em; text-indent:2em;">速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东方就<div style=" width:733px; height:488px; background:url(../images/yanshi.gif); margin:0 auto;"></div>速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东速度是多少到山顶山东省是的是的是的是的是的是速度速度十分感激加快递费订房京东方第三方就偶是打飞机水电费家欧式的肌肤水豆腐搜到三点多金佛嗖嗖的飞机速度欧舒丹法搜的经费都是佛山东</div>';
	for(var i=0;i<sige.length;i++)
	{
		
		sige[i].onmouseover=function()
		{
			this.style.cursor="pointer";
			this.style.opacity="0.5";
		}
		sige[i].onmouseout=function()
		{
			this.style.opacity="1";
		}
	}
	
	
	var shangyiye=document.getElementById("shangyiye");
	var xiayiye=document.getElementById("xiayiye");
	
	shangyiye.onclick=function()
	{
		
		zuobian.innerHTML=limian;
	}
	xiayiye.onclick=function()
	{
		
		zuobian.innerHTML=limiann;
	}
	
	
	
}