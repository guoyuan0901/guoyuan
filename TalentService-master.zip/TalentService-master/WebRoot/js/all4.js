// JavaScript Document
var c,k;
window.onload=function()
{
	k();
}
