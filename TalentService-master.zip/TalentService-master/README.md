# TalentService
主要是为了学生的实习实践任务的平台，企业在平台上承接任务并且发布项目给学生。因此，学校可以根据企业对学生完成项目的情况的评价打分。 <br>
主要开发人员为三人：设计，前端和后端（我）。 <br>
项目使用SSH，JBPM，Lucene + iKanalyzer，EasyUI, WebSocket, Html + css + jQyuery
